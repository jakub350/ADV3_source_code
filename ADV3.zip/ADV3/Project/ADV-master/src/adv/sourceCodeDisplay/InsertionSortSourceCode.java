package adv.sourceCodeDisplay;

import java.awt.EventQueue;

public class InsertionSortSourceCode extends SourceCodeDisplayFrame{
	public InsertionSortSourceCode() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					initializeSettings();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	@Override
	public void loadSourceCode() {
		addLine("for j <- 1 to A.length - 1 do", 1);
		addLine("a <- A[j]", 2);
		addLine("i = j-1", 2);
		addLine("while i >= 0 and A[i].key > a.key do", 2);
		addLine("A[i+1] <- A[i]", 3);
		addLine("i <- i-1", 3);
		addLine("A[i+1] <- a", 2);	
	}
}
