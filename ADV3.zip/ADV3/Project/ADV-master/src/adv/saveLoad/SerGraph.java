package adv.saveLoad;

import java.io.Serializable;
import java.util.Set;

import adv.directedGraphModel.Edge;
import adv.directedGraphModel.GElementDirectedGraph;
import adv.directedGraphModel.GElementVertex;
import edu.usfca.xj.appkit.gview.object.GElement;

public class SerGraph implements Serializable{

	String[] verticesName = new String[50];
	double[] verticesX = new double[50];
	double[] verticesY = new double[50];
	
	
	int[] edgeStart = new int[50];
	int[] edgeFinish = new int[50];
	
	
	
	int numberOfVertices = 0;
	int numberOfEdges = 0;
	
	public SerGraph(GElementDirectedGraph graph) {
		GElementVertex[] vertices = graph.getVertexSet();
		Set<Edge> edges = graph.getEdgeSet();
		 
		for (int i = 0 ; i < vertices.length ; i++) {
	            if (vertices[i] != null) {
	            	GElementVertex vertex = vertices[i];
	            	verticesName[i] = vertex.getVertexKey();
	            	verticesX[i] = vertex.getPositionX();
	            	verticesY[i] = vertex.getPositionY();
	            	numberOfVertices++;
	            }
	    }
		
		for (Edge e : edges) {
		    edgeStart[numberOfEdges] = e.getFromVertex();
		    edgeFinish[numberOfEdges] = e.getToVertex();
		    numberOfEdges++;
		} 
		  
	}
	
	public String getVertexName(int i){
		return verticesName[i];
	}
	
	public double getVertexX(int i){
		return verticesX[i];
	}
	
	public double getVertexY(int i){
		return verticesY[i];
	}
	
	public int getNumberOfVertices(){
		return numberOfVertices;
	}
	public int getNumberOfEdges(){
		return numberOfEdges;
	}
	public int getEdgeStart(int i){
		return edgeStart[i];
	}
	public int getEdgeFinish(int i){
		return edgeFinish[i];
	}
}
