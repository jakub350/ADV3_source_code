package adv.panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;

import adv.main.Window;
import adv.sortingInputHandler.HeapSortInputDialog;
import adv.sortingInputHandler.ExternalMergeSortInputDialog;
import adv.sortingInputHandler.SortInputDialog;
import adv.sourceCodeDisplay.BubbleSortSourceCode;
import adv.sourceCodeDisplay.ExternalMergeSortSourceCode;
import adv.views.ExternalMergeSortView;
import adv.views.HeapSortView;

public class ExternalMergeSortPanel extends Panel{
	
	private ExternalMergeSortView externalMergeSortView;
	private JButton newInput;
	private Font f = new Font(Font.DIALOG,Font.PLAIN,16);
	private ExternalMergeSortInputDialog dialog;
	private final static int SLOW_INDEX = 0;
	private final static int MEDIUM_INDEX = 1;
	private final static int FAST_INDEX = 2;
	private final static int VERY_FAST_INDEX = 3;
	

	public ExternalMergeSortPanel(Window window) {
		super(window);

        newInput = new JButton("New Input");
        newInput.setFont(f);
        newInput.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                restartButton.setEnabled(false);
                displayInputDialog();	
            }

        });
        
        externalMergeSortSourceCode = new ExternalMergeSortSourceCode();
        
        setUpButtons(newInput);

        // add space behind insertField to make all the buttons and field align with left margin.
        addBlank(1100);

        this.add(view = externalMergeSortView = new ExternalMergeSortView(this));
        setUpAnimationPanel(view);

        dialog = new ExternalMergeSortInputDialog(this);
        
	}
	
	private void displayInputDialog() {
        dialog.setVisible(true);
    }

    @Override
    public void enableSpecificButtons() {
        newInput.setEnabled(true);

    }

    @Override
    public void disableSpecificButtons() {
        newInput.setEnabled(false);
    }

    @Override
    protected void setUpRestartButton(Box buttonsContainer) {
        super.setUpRestartButton(buttonsContainer);
    }

    @Override
    protected void setUpSpeedButton(Box buttonsContainer){
        String[] speedStrings = { "Slow", "Medium", "Fast", "Very Fast" };
        JComboBox<String> speed = new JComboBox<String>(speedStrings);
        speed.setMaximumSize(new Dimension(105, 33)); // set "speed" button the same size of other buttons
        speed.setFont(buttonFont);
        setAnimationSpeeds();
        speed.addActionListener(new ActionListener() {

                                    @Override
                                    public void actionPerformed(ActionEvent event) {
                                        JComboBox<String> speed = (JComboBox<String>) event.getSource();
                                        switch (speed.getSelectedIndex()) {
                                            case SLOW_INDEX:
                                                view.setDelay(slowValue);
                                                break;
                                            case MEDIUM_INDEX:
                                                view.setDelay(mediumValue);
                                                break;
                                            case FAST_INDEX:
                                                view.setDelay(fastValue);
                                                break;
                                            case VERY_FAST_INDEX:
                                                view.setDelay(veryFastValue);
                                                break;
                                        }
                                    }
                                }

        );
        speed.setSelectedItem(speedStrings[MEDIUM_INDEX]);
        buttonsContainer.add(speed);
        buttonsContainer.add(Box.createHorizontalStrut(350));

    }

    @Override
    protected void setUpAnimationRunning(){
        getRunningMsg().setText("Animation Running");
        getRunningMsg().setForeground(Color.GREEN);
        disableSpecificButtons();
    }


    @Override
    protected void endAnimation() {
        running = false;
        getRunningMsg().setText("Animation Completed");
        getRunningMsg().setForeground(Color.WHITE);
        stepButton.setEnabled(false);
        skipButton.setEnabled(false);
        restartButton.setEnabled(true);
        goButton.setText("Go");
        goButton.setEnabled(false);
        enableSpecificButtons();
    }


    //set the label for displaying the algorithm running information
    public void setLabel(String label){
        setMsgText(label);
    }


	public ExternalMergeSortView getExternalMergeSortView() {
		return externalMergeSortView;
	}
	
	@Override
	protected void setUpShowSourceCodeButton(Box buttonsContainer){
		showSourceCodeButton = new JButton("Show/Hide pseudo code");
		showSourceCodeButton.setEnabled(true);
		showSourceCodeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				externalMergeSortSourceCode.showHideSourceCode();
			}
		});
		buttonsContainer.add(showSourceCodeButton);
	}
	
	@Override
	public void highlight(int index) {
		externalMergeSortSourceCode.highlight(index);
	}

	@Override
	public void clearHighlight(int index) {
		externalMergeSortSourceCode.clearHighlight(index);
	}
	
	protected void setAnimationSpeeds() {
		slowValue = 200;
		mediumValue = 150;
		fastValue = 75;
		veryFastValue = 15;
	}
	
	@Override
	protected void setUpSaveButton(Box buttonsContainer){
		saveButton = new JButton("Save");
		saveButton.setEnabled(true);
		saveButton.setMaximumSize(new Dimension(80, 33)); // set "zoom" button the same size of other buttons
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JFileChooser fileChooser = new JFileChooser();
				if (fileChooser.showSaveDialog(saveButton) == JFileChooser.APPROVE_OPTION) {
					File file = fileChooser.getSelectedFile();
					externalMergeSortView.saveArray(file);
				}
			}
		});
		buttonsContainer.add(saveButton);
		selectAllButton.setFont(buttonFont);
	}
	
	@Override
	protected void setUpLoadButton(Box buttonsContainer){
		loadButton = new JButton("Load");
		loadButton.setEnabled(true);
		loadButton.setMaximumSize(new Dimension(80, 33)); // set "zoom" button the same size of other buttons
		loadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JFileChooser fileChooser = new JFileChooser();
				if (fileChooser.showOpenDialog(saveButton) == JFileChooser.APPROVE_OPTION){
					File file = fileChooser.getSelectedFile();
					externalMergeSortView.loadArray(file);
					enableGoAndSkip();
				}
			}
		});
		buttonsContainer.add(loadButton);
		selectAllButton.setFont(buttonFont);
		skipButton.setEnabled(true);
	}
	
}
