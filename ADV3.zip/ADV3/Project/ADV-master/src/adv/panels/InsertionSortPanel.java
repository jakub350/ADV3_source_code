package adv.panels;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;

import adv.main.Window;
import adv.sourceCodeDisplay.InsertionSortSourceCode;
import adv.views.InsertionSortView;

public class InsertionSortPanel extends SortPanel {

	protected final static int SLOW_VALUE = 75;
	protected final static int MEDIUM_VALUE = 50;
	protected final static int FAST_VALUE = 15;
	protected final static int VERY_FAST_VALUE = 5;
	

	public InsertionSortPanel(Window window) {
		super(window);
		this.add(view = sortView = new InsertionSortView(this));
		
		insertionSortSourceCode = new InsertionSortSourceCode();
		
		//view.setLocation(600,600);
		setUpAnimationPanel(view);
	}
	
	@Override
	protected void setUpShowSourceCodeButton(Box buttonsContainer){
		showSourceCodeButton = new JButton("Show/Hide pseudo code");
		showSourceCodeButton.setEnabled(true);
		showSourceCodeButton.setMaximumSize(new Dimension(80, 33));
		showSourceCodeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				insertionSortSourceCode.showHideSourceCode();
			}
		});
		buttonsContainer.add(showSourceCodeButton);
	}
	
	@Override
	public void highlight(int index) {
		insertionSortSourceCode.highlight(index);
	}

	@Override
	public void clearHighlight(int index) {
		insertionSortSourceCode.clearHighlight(index);
	}

	protected void setAnimationSpeeds() {
		slowValue = 200;
		mediumValue = 150;
		fastValue = 75;
		veryFastValue = 15;
	}
	
}
