package adv.utility;

import java.awt.*;

/**
 * Created by CK on 11/03/15.
 */

public class ColorConstants {

    public static final Color ANDROID_BLUE = new Color(0x33B5E5);
    public static final Color ANDROID_RED = new Color(0xFF4444);
    public static final Color ANDROID_PINK = new Color(0x9932CC);
    
    public static final Color ANDROID_COLOUR1 = new Color(0x2332CC);
    public static final Color ANDROID_COLOUR2 = new Color(0x23371C);
	public static final Color ANDROID_COLOUR3 = new Color(0xB39CF3);
	
	public static final Color ANDROID_GREY1 = new Color(0x89847A);
	public static final Color ANDROID_GREY2 = new Color(0x9E9D8B);
	public static final Color ANDROID_GREY3 = new Color(0x75B384);
	public static final Color ANDROID_GREY4 = new Color(0xA9A6DA);

}
