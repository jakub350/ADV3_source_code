package adv.utility;

import java.awt.*;

/**
 * Created by CK on 11/03/15.
 */
public class AppDimensions {

    public static Dimension CANVAS_SIZE = new Dimension(1368, 768);

}
