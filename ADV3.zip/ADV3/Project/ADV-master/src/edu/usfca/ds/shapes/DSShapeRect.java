package edu.usfca.ds.shapes;

import edu.usfca.xj.appkit.gview.object.GElementRect;
import edu.usfca.xj.foundation.XJXMLSerializable;

public class DSShapeRect extends GElementRect implements XJXMLSerializable {

    public DSShapeRect() {
        super();
    }
}
