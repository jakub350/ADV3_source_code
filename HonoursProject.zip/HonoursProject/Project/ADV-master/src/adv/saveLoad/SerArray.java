package adv.saveLoad;

import java.io.Serializable;

public class SerArray implements Serializable{
	
	private int arrayLocationValue[] = new int[100];
	private int block;
	private int n;

	public SerArray(int[] numArray) {
		arrayLocationValue = numArray;
	}
	public SerArray(int[] numArray, int block, int n) {
		arrayLocationValue = numArray;
		this.n = n;
		this.block = block;
	}
	
	public int[] getArray(){
		return arrayLocationValue;
	}
	public int getBlock() {
		return block;
	}
	public int getSize() {
		return n;
	}
}
