package adv.panels;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JButton;

import adv.main.Window;
import adv.sourceCodeDisplay.BubbleSortSourceCode;
import adv.views.BubbleSortView;

public class BubbleSortPanel extends SortPanel {

	protected final static int SLOW_VALUE = 75;
	protected final static int MEDIUM_VALUE = 50;
	protected final static int FAST_VALUE = 15;
	protected final static int VERY_FAST_VALUE = 5;
	

	public BubbleSortPanel(Window window) {
		super(window);
		this.add(view = sortView = new BubbleSortView(this));
		
		bubbleSortSourceCode = new BubbleSortSourceCode();
		
		//view.setLocation(600,600);
		setUpAnimationPanel(view);
	}
	
	@Override
	protected void setUpShowSourceCodeButton(Box buttonsContainer){
		showSourceCodeButton = new JButton("Show/Hide pseudo code");
		showSourceCodeButton.setEnabled(true);
		showSourceCodeButton.setMaximumSize(new Dimension(80, 33));
		showSourceCodeButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				bubbleSortSourceCode.showHideSourceCode();
			}
		});
		buttonsContainer.add(showSourceCodeButton);
	}
	
	@Override
	public void highlight(int index) {
		bubbleSortSourceCode.highlight(index);
	}

	@Override
	public void clearHighlight(int index) {
		bubbleSortSourceCode.clearHighlight(index);
	}
	
	protected void setAnimationSpeeds() {
		slowValue = 200;
		mediumValue = 150;
		fastValue = 75;
		veryFastValue = 15;
	}
	
}
