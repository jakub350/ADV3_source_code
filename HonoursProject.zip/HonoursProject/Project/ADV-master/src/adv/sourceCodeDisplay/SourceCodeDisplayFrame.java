package adv.sourceCodeDisplay;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import java.util.concurrent.TimeUnit;

import java.awt.*;

public class SourceCodeDisplayFrame {

	protected JFrame frame;
	protected JTextField[] textFields;
	protected static boolean visibleSourceCode = false;
	
	private int numberOfLines = 0;
	
	
	public void SourceCodeDisplayFrame() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				
			}
		});
	}
	
	public void initializeSettings() {
		try {
			frame.setVisible(false);
			frame.setAlwaysOnTop(true);
			frame.setDefaultCloseOperation(0);
			frame.getContentPane().setBackground(Color.WHITE);
			frame.addWindowListener(new java.awt.event.WindowAdapter() {
		        @Override
		        public void windowClosing(java.awt.event.WindowEvent windowEvent) {
		            frame.setVisible(false);
		            visibleSourceCode = false;
		        }
		    });
			loadSourceCode();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void showHideSourceCode(){
		if (visibleSourceCode == false) {
			frame.setVisible(true);
			visibleSourceCode = true;
		}
		else {
			frame.setVisible(false);
			visibleSourceCode = false;
		}
	}
	
	public void showSourceCode() {
		frame.setVisible(true);
	}
	public void hideSourceCode() {
		frame.setVisible(false);
	}

	public SourceCodeDisplayFrame() {
		initialize();
	}

	private void initialize() {
		this.textFields = new JTextField[50];
		frame = new JFrame();
		frame.setLayout(null);
		frame.setBounds(10, 10, 600, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	}
	
	public void addLine(String string, int indent) {
		for(int i=0;i<indent;i++) string = "   " + string;
		textFields[numberOfLines] = new JTextField();
		textFields[numberOfLines].setText(string);
		textFields[numberOfLines].setBorder(javax.swing.BorderFactory.createEmptyBorder());
		textFields[numberOfLines].setBounds(0,25*numberOfLines,1000,25);
		frame.add(textFields[numberOfLines]);
		numberOfLines++;
		frame.setBounds(500, 400, 600, (numberOfLines*25) + 37);
	}
	
	public void clearHighlight(int index) {
		textFields[index-1].setBackground(Color.WHITE);
	}
	
	public void highlight(int index) {
		textFields[index-1].setBackground(new Color(0,0,182,80));
	}
	
	public void loadSourceCode() {
		
	}

}
