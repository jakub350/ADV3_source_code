package adv.sourceCodeDisplay;

import java.awt.EventQueue;

public class ExternalMergeSortSourceCode extends SourceCodeDisplayFrame{
	public ExternalMergeSortSourceCode() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					initializeSettings();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	@Override
	public void loadSourceCode() {
		addLine("for i = 1 to n/K do", 1);
		addLine("read block-i of disc-A into memory", 2);
		addLine("sort block-i in memory using any 'in-place' algorithm", 2);
		addLine("write the sort of block-i out to disc-B", 2);
		addLine("disc-B now becomes current input-disc", 1);
		addLine("", 1);
		addLine("for  j = 1 to lg(n/K) do", 1);
		addLine("for  i = 1 to lg(n/2^j*K) do", 2);
		addLine("buffer the first K/3 entries of block-i and block-i + 1 from current input-disk into the memory", 3);
		addLine("initialize the output buffer b (of size K/3)", 3);
		addLine("while there are items left to sort do", 3);
		addLine("perform externalMerge on the small blocks in-memory", 4);
		addLine("od", 3);
		addLine("swap the current input-disk between A and B", 1);
	}
}
