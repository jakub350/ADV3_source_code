public class Test {

	public static void main(String[] args) {

		for (int i = 0; i < 20; i++) {
			
			for (int j = 0; j < 20; j++) {
				
				String key = i+""+j;
				System.out.println(key);
				
			}
			
		}
	}

}
