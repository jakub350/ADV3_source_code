package adv.views;

import java.awt.Color;
import java.awt.Toolkit;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import edu.usfca.xj.appkit.gview.base.Vector2D;

import adv.panels.ExternalMergeSortPanel;
import adv.panels.HeapSortPanel;
import adv.saveLoad.SerArray;
import adv.utility.ColorConstants;
import edu.usfca.ds.shapes.DSShapeRect;
import edu.usfca.xj.appkit.gview.object.GElement;
import edu.usfca.xj.appkit.gview.object.GElementRect;

public class ExternalMergeSortView extends View{
	
	
	public static final int block1PositionX = 150;
	public static final int initialDistanceY = 150;
	public static final int distanceY = 150;
	public static final int blockHeight = initialDistanceY+distanceY;
	public static final int blockSize = 30;
	
	private static final int waitTime = 20;
	
	protected GElementRect arrayDisc1[];
	protected GElementRect arrayDisc2[];
	protected GElementRect arrayBlock1[];
	protected GElementRect arrayBlock2[];
	protected GElementRect arrayBlock3[];
	protected GElementRect mainMem;
	protected GElementRect titles[];

	protected Color colors[];
	
	
	protected int n;
	protected int K;
	protected int K3;
	protected int position;
	protected int swapCounter = 0;
	protected int indexC = 0;
	
	protected int numberInB1;
	protected int numberInB2;
	protected int numberInB3;
	
	protected int[] arrayLocationValue = new int[50];

	protected ExternalMergeSortPanel panel;
	
	public ExternalMergeSortView(ExternalMergeSortPanel panel) {
		this.panel = panel;
	}

	public void initializeBars() {

		arrayDisc1 = new GElementRect[100];
		arrayDisc2 = new GElementRect[100];
		arrayBlock1 = new GElementRect[100];
		arrayBlock2 = new GElementRect[100];
		arrayBlock3 = new GElementRect[100];
		titles = new GElementRect[3];
		mainMem = new GElementRect();
		
		
		printDisc1(n);
		printMainMem();
		printDisc2(n);
		printBlock1(25);
		printBlock2(25);
		printBlock3(25);
	}
	
	public void initializeVariables(){
		
		colors = new Color[5];
		
		colors[0] =  new Color(0x37AFA9);
		colors[1] =  new Color(0x2D8E87);
		colors[2] =  new Color(0x6D9B73);
		colors[3] =  new Color(0xE8F2F2);
		colors[4] =  new Color(0xC9C9BD);
		
		K3 = K*3;
		position = 0;
	}
	
	private DSShapeRect createSegmentRec(String label, double x, double y, double w, double h) {
		DSShapeRect c = new DSShapeRect();
        c.setLabel(label);
        c.setSize(w, h);
        c.setPositionOfUpperLeftCorner(x,y);
        c.setDraggable(false);

        shapes.add(c);
        addElement(c);

        return c;
	}
	
	
	public void printDisc1(int size) {
		
		titles[0] = createSegmentRec("Input disc", block1PositionX + 30,initialDistanceY-30,50,20);
		titles[0].setLabelColor(Color.GREEN);
		titles[0].setOutlineColor(Color.WHITE);
		((GElementRect) titles[0]).setElementVisible(true);
		
		for(int i=0;i<size;i++) {
			arrayDisc1[i] = createSegmentRec("", block1PositionX + (i * blockSize), initialDistanceY, blockSize, blockSize);
	        arrayDisc1[i].setFillColor(colors[4]);
	        arrayDisc1[i].setOutlineColor(colors[4]);
	        arrayDisc1[i].setLabel(Integer.toString(arrayLocationValue[i]));
	        ((GElementRect) arrayDisc1[i]).setElementVisible(true);
		}
		
	}
	
	public void setColourDisc1(int index1,int index2, Color color) {
		for(int i=index1; i<index2;i++) {
			arrayDisc1[i].setFillColor(color);
	        arrayDisc1[i].setOutlineColor(color);
		}
	}
	
	public void printMainMem() {
		
		titles[2] = createSegmentRec("Main memory", block1PositionX + 30,initialDistanceY+distanceY-30,50,20);
		titles[2].setOutlineColor(Color.WHITE);
		((GElementRect) titles[2]).setElementVisible(true);
		
		mainMem = createSegmentRec("", block1PositionX, initialDistanceY+distanceY, blockSize*K3, blockSize);
		mainMem.setFillColor(colors[4]);
        ((GElementRect) mainMem).setElementVisible(true);
	}
	
	public void printDisc2(int size) {
		
		titles[1] = createSegmentRec("Output disc", block1PositionX + 30,(initialDistanceY+distanceY*2)-30,50,20);
		titles[1].setLabelColor(Color.RED);
		titles[1].setOutlineColor(Color.WHITE);
		((GElementRect) titles[1]).setElementVisible(true);
		
		for(int i=0;i<size;i++) {
			arrayDisc2[i] = createSegmentRec("", block1PositionX + (i * blockSize), initialDistanceY+distanceY*2, blockSize, blockSize);
	        arrayDisc2[i].setFillColor(colors[4]);
	        arrayDisc2[i].setOutlineColor(colors[4]);
	        arrayDisc2[i].setLabel("0");
	        ((GElementRect) arrayDisc2[i]).setElementVisible(true); 
		}
		
	}
	
	public void printBlock1(int size) {
		for(int i=0;i<size;i++) {
			arrayBlock1[i] = createSegmentRec("", block1PositionX + (i * blockSize), blockHeight, blockSize, blockSize);

	        arrayBlock1[i].setLabel("0");
	        ((GElementRect) arrayBlock1[i]).setElementVisible(false);
	        
	    	numberInB1 = 0;
		}
	}
	
	public void printBlock2(int size) {
		for(int i=0;i<size;i++) {
			arrayBlock2[i] = createSegmentRec("", block1PositionX + (K * blockSize) + (i * blockSize), blockHeight, blockSize, blockSize);

	        arrayBlock2[i].setLabel("0");
	        ((GElementRect) arrayBlock2[i]).setElementVisible(false);
	        
	        numberInB2 = 0;
		}
	}
	public void printBlock3(int size) {
		for(int i=0;i<size;i++) {
			arrayBlock3[i] = createSegmentRec("", block1PositionX + (K * 2 * blockSize) + (i * blockSize), blockHeight, blockSize, blockSize);

	        arrayBlock3[i].setLabel("0");
	        ((GElementRect) arrayBlock3[i]).setElementVisible(false);
	        
	        numberInB3 = 0;
		}
	}
	
	public void setColourDisc2(int index1,int index2, Color color) {
		for(int i=index1; i<index2;i++) {
			arrayDisc2[i].setFillColor(color);
	        arrayDisc2[i].setOutlineColor(color);
		}
	}
	
	public void fromDisc1toBlock1(int index1, int index2, Color color){
		
		GElementRect movable = new GElementRect();
		GElementRect helper[] = new GElementRect[100];
		
		for(int i=index1;i<index2;i++){
			helper[i] = createSegmentRec(arrayDisc1[i].getLabel(), arrayDisc1[i].getPositionX() - (blockSize/2), arrayDisc1[i].getPositionY()- (blockSize/2), blockSize, blockSize);
			helper[i].setFillColor(color);
	        helper[i].setOutlineColor(color);
	        ((GElementRect) helper[i]).setElementVisible(true);
			movable.addElement(helper[i]);
		}

		AnimatePath(movable,movable.getPosition(),new Vector2D((blockSize/2)-movable.getFirstElement().getPositionX()+block1PositionX,(blockSize/2)-movable.getFirstElement().getPositionY()+blockHeight), 10);
		
		for(int i=0;i<index2-index1;i++) {
			((GElementRect) helper[i+index1]).setElementVisible(false);
			arrayBlock1[i].setFillColor(color);
			arrayBlock1[i].setOutlineColor(color);
			arrayBlock1[i].setLabel(helper[i+index1].getLabel());
			((GElementRect) arrayBlock1[i]).setElementVisible(true);
		}

		numberInB1 = index2-index1;
	}
	
    public void fromDisc1toBlock2(int index1, int index2, Color color){
		
		GElementRect movable = new GElementRect();
		GElementRect helper[] = new GElementRect[100];
		
		for(int i=index1;i<index2;i++){
			helper[i] = createSegmentRec(arrayDisc1[i].getLabel(), arrayDisc1[i].getPositionX() - (blockSize/2), arrayDisc1[i].getPositionY()- (blockSize/2), blockSize, blockSize);
			helper[i].setFillColor(color);
	        helper[i].setOutlineColor(color);
	        ((GElementRect) helper[i]).setElementVisible(true);
			movable.addElement(helper[i]);
		}

		AnimatePath(movable,movable.getPosition(),new Vector2D((blockSize/2)-movable.getFirstElement().getPositionX()+block1PositionX + (K * blockSize),(blockSize/2)-movable.getFirstElement().getPositionY()+blockHeight), 10);
		

		for(int i=0;i<index2-index1;i++) {
			
			((GElementRect) helper[i+index1]).setElementVisible(false);
			arrayBlock2[i].setFillColor(color);
			arrayBlock2[i].setOutlineColor(color);
			arrayBlock2[i].setLabel(helper[i+index1].getLabel());
			((GElementRect) arrayBlock2[i]).setElementVisible(true);
		}
		
		numberInB2 = index2-index1;
	}
    
    public void fromBlock1toBlock3(){
		GElementRect movable = new GElementRect();
		movable = createSegmentRec("", arrayBlock1[numberInB1-1].getPositionX()-(blockSize/2), arrayBlock1[numberInB1-1].getPositionY()-(blockSize/2), blockSize, blockSize);
		movable.setFillColor(colors[indexC]);
		movable.setOutlineColor(colors[indexC]);
		movable.setLabel(arrayBlock1[numberInB1-1].getLabel());
        ((GElementRect) movable).setElementVisible(true);
        
        ((GElementRect) arrayBlock1[numberInB1-1]).setElementVisible(false);
        
        AnimatePath(movable,movable.getPosition(), arrayBlock3[numberInB3].getPosition(), 10);
        

        ((GElementRect) movable).setElementVisible(false);
        arrayBlock3[numberInB3].setLabel(movable.getLabel());
        arrayBlock3[numberInB3].setFillColor(colors[indexC]);
        arrayBlock3[numberInB3].setOutlineColor(colors[indexC]);
        ((GElementRect) arrayBlock3[numberInB3]).setElementVisible(true);
        

        numberInB1--;
        numberInB3++;
	}
    
    public void fromBlock2toBlock3(){
		GElementRect movable = new GElementRect();
		movable = createSegmentRec("", arrayBlock1[numberInB2-1].getPositionX()-(blockSize/2), arrayBlock2[numberInB2-1].getPositionY()-(blockSize/2), blockSize, blockSize);
		movable.setFillColor(colors[indexC]);
		movable.setOutlineColor(colors[indexC]);
		movable.setLabel(arrayBlock2[numberInB2-1].getLabel());
        ((GElementRect) movable).setElementVisible(true);
        
        ((GElementRect) arrayBlock2[numberInB2-1]).setElementVisible(false);
        
        AnimatePath(movable,movable.getPosition(), arrayBlock3[numberInB3].getPosition(), 10);
        

        ((GElementRect) movable).setElementVisible(false);
        arrayBlock3[numberInB3].setLabel(movable.getLabel());
        arrayBlock3[numberInB3].setFillColor(colors[indexC]);
        arrayBlock3[numberInB3].setOutlineColor(colors[indexC]);
        ((GElementRect) arrayBlock3[numberInB3]).setElementVisible(true);
        
        
		
        numberInB2--;
        numberInB3++;
	}
    
    public void fromBlock1toDisc2(int index1,Color color){
		
		GElementRect movable = new GElementRect();
		GElementRect helper[] = new GElementRect[100];
		
		for(int i=0;i<numberInB1;i++){
			helper[i] = createSegmentRec(arrayBlock1[i].getLabel(), arrayBlock1[i].getPositionX() - (blockSize/2), arrayBlock1[i].getPositionY()- (blockSize/2), blockSize, blockSize);
			helper[i].setFillColor(color);
	        helper[i].setOutlineColor(color);
	        ((GElementRect) helper[i]).setElementVisible(true);
	        ((GElementRect) arrayBlock1[i]).setElementVisible(false);
			movable.addElement(helper[i]);
		}

		AnimatePath(movable,movable.getPosition(),new Vector2D(-movable.getFirstElement().getPositionX()+arrayDisc2[index1].getPositionX(),-movable.getFirstElement().getPositionY()+arrayDisc2[index1].getPositionY()), 25);
		
		for(int i=index1;i<index1+numberInB1;i++){
			arrayDisc2[i].setLabel(helper[i-index1].getLabel());
			arrayDisc2[i].setFillColor(colors[indexC]);
			arrayDisc2[i].setOutlineColor(colors[indexC]);
			((GElementRect) helper[i-index1]).setElementVisible(false);
		}
		indexC++;
		if(indexC==2) indexC = 0;
		
		
		numberInB1 = 0;
	}

 	public void fromBlock3toDisc2(int index1){
		
		GElementRect movable = new GElementRect();
		GElementRect helper[] = new GElementRect[100];
		
		for(int i=0;i<numberInB3;i++){
			helper[i] = createSegmentRec(arrayBlock3[i].getLabel(), arrayBlock3[i].getPositionX() - (blockSize/2), arrayBlock3[i].getPositionY()- (blockSize/2), blockSize, blockSize);
			helper[i].setFillColor(colors[indexC]);
	        helper[i].setOutlineColor(colors[indexC]);
	        ((GElementRect) helper[i]).setElementVisible(true);
	        ((GElementRect) arrayBlock3[i]).setElementVisible(false);
			movable.addElement(helper[i]);
		}

		AnimatePath(movable,movable.getPosition(),new Vector2D(-movable.getFirstElement().getPositionX()+arrayDisc2[index1].getPositionX(),-movable.getFirstElement().getPositionY()+arrayDisc2[index1].getPositionY()), 25);
		
		for(int i=index1;i<index1+numberInB3;i++){
			arrayDisc2[i].setLabel(helper[i-index1].getLabel());
			arrayDisc2[i].setFillColor(colors[indexC]);
			arrayDisc2[i].setOutlineColor(colors[indexC]);
			((GElementRect) helper[i-index1]).setElementVisible(false);
		}
		
		
		numberInB3 = 0;
	}
    
    public void sortBlock1(){
    	int[] helper = new int[numberInB1];
    	for(int i=0;i<numberInB1;i++) {
    		helper[i]=Integer.parseInt(arrayBlock1[i].getLabel());
    	}
    	
    	Arrays.sort(helper);
    	
    	for(int i=0;i<numberInB1;i++) {
    		arrayBlock1[i].setLabel(Integer.toString(helper[i]));
    	}
    }
    
    public void reverseBlock1(){
    	Integer[] helper = new Integer[numberInB1];
    	for(int i=0;i<numberInB1;i++) {
    		helper[i]=Integer.parseInt(arrayBlock1[i].getLabel());
    	}
    	
    	Arrays.sort(helper, Collections.reverseOrder());
    	
    	for(int i=0;i<numberInB1;i++) {
    		arrayBlock1[i].setLabel(Integer.toString(helper[i]));
    	}
    }
    
    public void reverseBlock2(){
    	Integer[] helper = new Integer[numberInB2];
    	for(int i=0;i<numberInB2;i++) {
    		helper[i]=Integer.parseInt(arrayBlock2[i].getLabel());
    	}
    	
    	Arrays.sort(helper, Collections.reverseOrder());
    	
    	for(int i=0;i<numberInB2;i++) {
    		arrayBlock2[i].setLabel(Integer.toString(helper[i]));
    	}
    }
    
    public void fromDisc2toDisc1(){
    	/*GElementRect movable = new GElementRect();
		GElementRect helper[] = new GElementRect[100];
		
		for(int i=0;i<n;i++){
			helper[i] = createSegmentRec(arrayDisc2[i].getLabel(), arrayDisc2[i].getPositionX() - 10, arrayDisc2[i].getPositionY()- 10, 20, 20);
			helper[i].setFillColor(ColorConstants.ANDROID_GREY4);
	        helper[i].setOutlineColor(ColorConstants.ANDROID_GREY4);
	        ((GElementRect) helper[i]).setElementVisible(true);
	        arrayDisc2[i].setFillColor(colors[4]);
	        arrayDisc2[i].setOutlineColor(colors[4]);
			movable.addElement(helper[i]);
		}

		AnimatePath(movable,movable.getPosition(),new Vector2D(-movable.getFirstElement().getPositionX()+arrayDisc1[0].getPositionX(),-movable.getFirstElement().getPositionY()+arrayDisc1[0].getPositionY()), 25);
			
		for(int i=0;i<n;i++){
			arrayDisc1[i].setLabel(helper[i].getLabel());
			((GElementRect) helper[i]).setElementVisible(false);
		}*/
    	
    	swapDisc1Disc2(n);
    	swapCounter++;
		
		numberInB1 = 0;
		position=0;
    }
    
    public void swapDisc1Disc2(int size){
    	GElementRect helper1 = new GElementRect();
    	helper1.setLabelColor(titles[0].getLabelColor());
    	helper1.setLabel(titles[0].getLabel());
    	
    	titles[0].setLabelColor(titles[1].getLabelColor());
    	titles[0].setLabel(titles[1].getLabel());
    	
    	titles[1].setLabelColor(helper1.getLabelColor());
    	titles[1].setLabel(helper1.getLabel());
    	
    	for(int i=0;i<size;i++) {
    		GElementRect helper = new GElementRect();
    		helper.setLabel(arrayDisc1[i].getLabel());
    		helper.setPosition(arrayDisc1[i].getPosition());

    		
    		arrayDisc1[i].setLabel(arrayDisc2[i].getLabel());
    		arrayDisc1[i].setPosition(arrayDisc2[i].getPosition());

    		
    		arrayDisc2[i].setLabel("");
    		arrayDisc2[i].setPosition(helper.getPosition());
	        arrayDisc2[i].setFillColor(colors[4]);
	        arrayDisc2[i].setOutlineColor(colors[4]);
    	}
    }
    
    public void partA(){
    	panel.setMsgText("Part A");
    	int numberOfElem = n;
    	int position = 0;
    	int counter = 1;
    	while(numberOfElem!=0){
    		if(numberOfElem>(K*3)){
    			panel.highlight(2);
    			panel.setMsgText("Fetch a block from the disc.");
    			
    			Color c;
    			if(counter == 0 ) {
    				counter = 1;
    				c = new Color(0x37AFA9);
    				c = colors[1];
    			}
    			else {
    				counter = 0;
    				c = new Color(0x37AFA9);
    				c = colors[0];
    			}

    			setColourDisc1(position,position+(K*3),c);
    			fromDisc1toBlock1(position,position+(K*3),c);
    			repaintwait(waitTime);
    			panel.clearHighlight(2);
    			panel.highlight(3);
    			panel.setMsgText("Sort the fetched block 'in place'.");
    			sortBlock1();
    			repaintwait(waitTime*2);
    			panel.clearHighlight(3);
    			panel.highlight(4);
    			panel.setMsgText("Move the block to the disc.");
    			repaintwait(waitTime);
    			fromBlock1toDisc2(position,c);
    			panel.clearHighlight(4);
    			position +=(K*3);
    			numberOfElem-=(K*3);
    		}
    		else{
    			
    			panel.highlight(2);
    			panel.setMsgText("Fetch a block from th disc.");
    			
    			Color c;
    			if(counter == 0 ) {
    				counter = 1;
    				c = new Color(0x37AFA9);
    				c = colors[1];
    			}
    			else {
    				counter = 0;
    				c = new Color(0x37AFA9);
    				c = colors[0];
    			}

    			setColourDisc1(position,position+numberOfElem,c);
    			fromDisc1toBlock1(position,position+numberOfElem,c);
    			
    			
    			repaintwait(waitTime);
    			panel.clearHighlight(2);
    			panel.highlight(3);
    			panel.setMsgText("Sort the fetched block 'in place'.");
    			sortBlock1();
    			repaintwait(waitTime*2);
    			panel.clearHighlight(3);
    			panel.highlight(4);
    			panel.setMsgText("Move the block to the disc.");
    			repaintwait(waitTime);
    			fromBlock1toDisc2(position,c);
    			panel.clearHighlight(4);
    			position +=numberOfElem;
    			numberOfElem=0;
    		}
    	}
    	repaintwait(waitTime*2);
    	panel.highlight(5);
    	panel.setMsgText("Read from the other disc");
    	fromDisc2toDisc1();
    	repaintwait(waitTime);
    	panel.clearHighlight(5);
    	repaintwait(waitTime);
    }
	
    public void partB() {
    	panel.setMsgText("Part B");
    	while(K3<n){
    		int j=0;
    		while(processBlocks(j) < n) {
    			j+=2;
    			indexC++;
    			if(indexC==2) indexC = 0;
    		}
    		K3*=2;
    		panel.highlight(14);
    		panel.setMsgText("Read from the other disc");
    		fromDisc2toDisc1();
    		panel.clearHighlight(14);
    	}
    	int discNr = 1;
    	if(swapCounter % 2 ==1) discNr = 2;
    	panel.setMsgText("The sorted array is in DISC " + discNr);
    }
    
    public int processBlocks(int ord){
    	int a1 = ord*K3;
		int a2 = a1 + K3 - 1;
		
		int b1 = a2 + 1;
		int b2 = a2 + K3;
		
		
		
		if(a1>=n){
			a1 = a2+2;
			b1 = b2+2;
		}
		else if(a2>=n) {
			a2 = n-1;
			b1 = b2+2;
		}
		else if(b1>=n){
			b1 = b2+2;
		}
		else if(b2>=n) {
			b2 = n-1;
		}
		
		int h1=a1;
		int h2=a2;
		int h3=b1;
		int h4=b2;
		setColourDisc1(h1,h2+1,colors[0]);
		setColourDisc1(h3,h4+1,colors[1]);
		
		
		while(a1<=a2 || b1<=b2) {//pages still exist

			if(numberInB1==0 && a1<=a2) {
				if(a1+K-1<=a2){
					panel.highlight(9);
					panel.setMsgText("Move data from the disc to the main memory.");
					fromDisc1toBlock1(a1, a1+K,arrayDisc1[a1].getFillColor());
					repaintwait(waitTime);
					panel.clearHighlight(9);
					setColourDisc1(a1,a1+K,colors[2]);
					reverseBlock1();
					repaintwait(waitTime);
					a1+=K;
				}
				else {
					panel.highlight(9);
					panel.setMsgText("Move data from the disc to the main memory.");
					fromDisc1toBlock1(a1, a2+1,arrayDisc1[a1].getFillColor());
					repaintwait(waitTime);
					panel.clearHighlight(9);
					setColourDisc1(a1,a2+1,colors[2]);
					reverseBlock1();
					repaintwait(waitTime);
					a1=a2+1;
				}
			}
			if(numberInB2==0 && b1<=b2) {
				if(b1+K-1<=b2){
					panel.highlight(9);
					panel.setMsgText("Move data from the disc to the main memory.");
					fromDisc1toBlock2(b1, b1+K,arrayDisc1[b1].getFillColor());
					repaintwait(waitTime);
					panel.clearHighlight(9);
					setColourDisc1(b1,b1+K,colors[2]);
					reverseBlock2();
					repaintwait(waitTime);
					b1+=K;
				}
				else {
					panel.highlight(9);
					panel.setMsgText("Move data from the disc to the main memory.");
					fromDisc1toBlock2(b1, b2+1,arrayDisc1[b1].getFillColor());
					repaintwait(waitTime);
					panel.clearHighlight(9);
					setColourDisc1(b1,b2+1,colors[2]);
					reverseBlock2();
					repaintwait(waitTime);
					b1=b2+1;
				}
			}
		
			
			if(numberInB1!=0 && numberInB2!=0){
				panel.highlight(12);
				panel.setMsgText("Merge data in the main memory.");
				merge(0);
				repaintwait(waitTime);
				panel.clearHighlight(12);
			}
			else {
				panel.highlight(12);
				panel.setMsgText("Merge data in the main memory.");
				merge(1);
				repaintwait(waitTime);
				panel.clearHighlight(12);
			}
		}
		
		if(numberInB1!=0 && numberInB2!=0){
			panel.highlight(12);
			panel.setMsgText("Merge data in the main memory.");
			merge(0);
			repaintwait(waitTime);
			panel.clearHighlight(12);
		}
		else {
			panel.highlight(12);
			panel.setMsgText("Merge data in the main memory.");
			merge(1);
			repaintwait(waitTime);
			panel.clearHighlight(12);
		}

		//setColourDisc1(h1,h2+1,colors[4]);
		//setColourDisc1(h3,h4+1,colors[4]);
		
		return a1;
		
    }
    
	
	public void merge(int flag){
		if(flag == 0) {
			while(numberInB1!=0 && numberInB2!=0){
				int n1 = Integer.parseInt(arrayBlock1[numberInB1-1].getLabel());
				int n2 = Integer.parseInt(arrayBlock2[numberInB2-1].getLabel());
				if(n1<n2) {
					fromBlock1toBlock3();
					if(numberInB3 == K) {
						panel.setMsgText("Move data from the main memory to the output disc.");
						fromBlock3toDisc2(position);
						panel.setMsgText("Merge data in the main memory.");
						position+=K;
					}
				}
				else {
					fromBlock2toBlock3();
					if(numberInB3 == K) {
						panel.setMsgText("Move data from the main memory to the output disc.");
						fromBlock3toDisc2(position);
						panel.setMsgText("Merge data in the main memory.");
						position+=K;
					}
				}
			}
		}
		
		else {
			while(numberInB1!=0){
				fromBlock1toBlock3();
				if(numberInB3 == K) {
					panel.setMsgText("Move data from the main memory to the output disc.");
					fromBlock3toDisc2(position);
					panel.setMsgText("Merge data in the main memory.");
					position+=K;
				}
			}
			while(numberInB2!=0){
				fromBlock2toBlock3();
				if(numberInB3 == K) {
					panel.setMsgText("Move data from the main memory to the output disc.");
					fromBlock3toDisc2(position);
					panel.setMsgText("Merge data in the main memory.");
					position+=K;
				}
			}
			if(numberInB1==0 && numberInB2==0 && numberInB3!=0) {
				int hlp = numberInB3;
				panel.setMsgText("Move data from the main memory to the output disc.");
				fromBlock3toDisc2(position);
				panel.setMsgText("Merge data in the main memory.");
				position+=hlp;
			}
		}
	}
	
	public void saveArray(File file){
    	SerArray array = new SerArray(arrayLocationValue,K,n);
    	try
        {
            FileOutputStream fs = new FileOutputStream(file);
            ObjectOutputStream os = new ObjectOutputStream(fs);
            os.writeObject(array);
            os.close();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void loadArray(File file){
    	SerArray array = new SerArray(arrayLocationValue);
    	try
        {
            FileInputStream fileStream = new FileInputStream(file);
            ObjectInputStream is = new ObjectInputStream(fileStream);
            array = (SerArray) is.readObject();
            //System.out.println(Arrays.toString(array.getArray()));
            setNewInput(array.getArray(),array.getBlock());
            n = array.getSize();
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    

	
	public void setNewInput(int[] numArray, int blockSize){

        setRootElement(null);
        panel.setLabel("");
        nullLabel = createLabel("",20,20);

        n = numArray.length;
        K = blockSize;
        
        for(int i = 0; i < n; i++) {
			arrayLocationValue[i]=numArray[i];
		}
	
    }
	
	public void runAlgorithm() {
		
    	initializeVariables();
		initializeBars();
		
		partA();
		partB();
	}
	
	
}
