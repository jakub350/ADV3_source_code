package adv.views;

import java.util.concurrent.TimeUnit;

import adv.panels.InsertionSortPanel;

public class InsertionSortView extends SortView {


	public InsertionSortView(InsertionSortPanel panel) {
		this.panel = panel;
	}

	public void insertionSort() {
		panel.highlight(1);
		sleep(2);
		panel.clearHighlight(1);
		for (int i = 0; i < currentNumElements; i++) {
			panel.highlight(2);
			sleep(2);
			panel.clearHighlight(2);
			panel.highlight(3);
			sleep(2);
			panel.clearHighlight(3);
			panel.highlight(4);
			sleep(1);
			int j=i;
			while (j > 0 && greaterThan(j-1, j)) {
				sleep(1);
				panel.clearHighlight(4);
				panel.highlight(5);
				sleep(1);
				swap(j - 1, j);
				sleep(1);
				panel.clearHighlight(5);
				panel.highlight(6);
				sleep(2);
				panel.clearHighlight(6);
				j--;
				panel.highlight(4);
			}
			panel.clearHighlight(4);
			panel.highlight(7);
			sleep(2);
			panel.clearHighlight(7);
		}
	}
	
	public void sleep(int seconds) {
		try {
			TimeUnit.SECONDS.sleep(seconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void runAlgorithm() {
		insertionSort();
		panel.setLabel("Elements sorted.");
	}

}
