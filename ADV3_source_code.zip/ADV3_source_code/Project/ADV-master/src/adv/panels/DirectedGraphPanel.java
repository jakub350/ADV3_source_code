package adv.panels;

import adv.main.Window;
import adv.views.DirectedGraphView;

import adv.views.View;
import edu.usfca.vas.window.tools.DesignToolsDG;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.Vector;
import java.io.File;


public abstract class DirectedGraphPanel extends Panel {

	protected DirectedGraphView graphView;
	protected DesignToolsDG designToolFA;
	
	


	public DirectedGraphPanel(Window window) {
		super(window);
		upContainer.add(designToolFA = new DesignToolsDG(this.window));
		addBlank(1019);
		

	}
	
	@Override
	protected void setUpSaveButton(Box buttonsContainer){
		saveButton = new JButton("Save");
		saveButton.setEnabled(true);
		saveButton.setMaximumSize(new Dimension(80, 33)); // set "zoom" button the same size of other buttons
		saveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JFileChooser fileChooser = new JFileChooser();
				if (fileChooser.showSaveDialog(saveButton) == JFileChooser.APPROVE_OPTION) {
					File file = fileChooser.getSelectedFile();
					graphView.saveGraph(file);
				  
				}
				

			}
		});
		buttonsContainer.add(saveButton);
		selectAllButton.setFont(buttonFont);
	}
	
	@Override
	protected void setUpLoadButton(Box buttonsContainer){
		loadButton = new JButton("Load");
		loadButton.setEnabled(true);
		loadButton.setMaximumSize(new Dimension(80, 33)); // set "zoom" button the same size of other buttons
		loadButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JFileChooser fileChooser = new JFileChooser();
				if (fileChooser.showOpenDialog(saveButton) == JFileChooser.APPROVE_OPTION) {
					File file = fileChooser.getSelectedFile();
					graphView.loadGraph(file);
				  
				}
			}
		});
		buttonsContainer.add(loadButton);
		selectAllButton.setFont(buttonFont);
		skipButton.setEnabled(true);
	}

	public void setLabel(String label){

		setMsgText(label);

	}
	


}


