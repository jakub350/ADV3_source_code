package adv.sourceCodeDisplay;

import java.awt.EventQueue;

public class HeapSortSourceCode extends SourceCodeDisplayFrame{

	public HeapSortSourceCode() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					initializeSettings();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	@Override
	public void loadSourceCode() {
		addLine("for (int i = 0; i < currentNumElements - 1; i++)", 1);
		addLine("for (int j = 0; j < currentNumElements - 1 - i; j++)", 2);
		addLine("if (greaterThan(j, j+1))", 3);
		addLine("swap(j + 1, j);", 4);
		addLine("else", 3);
		addLine("no action required", 4);	
	}
}
