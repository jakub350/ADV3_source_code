package adv.sourceCodeDisplay;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

import java.awt.*;

public class BubbleSortSourceCode extends SourceCodeDisplayFrame{

	public BubbleSortSourceCode() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					initializeSettings();
					frame.setTitle("Bubble Sort Source Code");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	@Override
	public void loadSourceCode() {
		
	}
}
